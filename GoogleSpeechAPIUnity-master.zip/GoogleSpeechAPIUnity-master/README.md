# GoogleSpeechAPIUnity
#GoogleSpeechAPIObject is responsible for handling stt operations
#on-of the script as u required
#There are some audio files to test which are in english and marathi
#change codes accordingaly
  

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Sw_try : MonoBehaviour
{

	public string api_key;
	public AudioClip ac;
	public string code;
	public Text t;
    // Start is called before the first frame update
    void Start()
    {
		
	}

	Sw_STT st = new Sw_STT();
    // Update is called once per frame
    void Update()
    {

	
	
	}
}
